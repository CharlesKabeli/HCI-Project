This is a Human Computer Interaction mini-project that was aimed at
demonstrating the students' application of concepts they have learnt from 
the class with regard to the design principles being visiblility, feedback,
constraints, consistency, affordance and mapping, as well as usability goals.

This website in particular is an improvement of an already existing website
which provides Sesotho language learning plartform and resources to Sesotho
language learners and teachers. Here is the link to the main website:
http://sesotho.web.za/ 

The aim is to create an appealing interface as well as add on the responsiveness
by adding other features such as user accounts and book borrowing system.

First export the sesotho.sql database found in "database" folder to the localhost
so that the images will be visible on the website and the user be able to login
using the credentials in the database. 